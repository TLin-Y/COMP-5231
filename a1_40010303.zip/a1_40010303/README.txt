1. The program has checked to meet all requirements.

2. For Linelist.print(), Line.Overload ==, !=, it's not in the A1.pdf, they are build for meet
'LineListDriver' program call.

3. For node, it has been hide inside of the LineList, "get/set" methods has been created.

4. The program is to read lines from "input_.txt" file, build string line to type "Line" and linked 
the lines with "node" to create the "Linelist". After generation, the member functions such
as "remove" "insert" has been tested to creat a new reordered "input_a" LineList.
   By calling overload operated == and != in "line.cpp line.h", reordered "input_a" is %100 meet
with "input_b", which means the program has been tested good.

5. "checkIndex","find" extra functions are used to make LineList safe and easy to use.


	 
